package featurecreep.api.registries;

import java.util.ArrayList;

import featurecreep.api.blocks.FCBlockAPI;
import featurecreep.api.blocks.vanilla.VanillaBlock;
import featurecreep.api.items.FCItemAPI;
import featurecreep.api.items.datafied.dmr.DMRItem;
import featurecreep.api.items.vanilla.VanillaItem;

public class FCRegistries {

  public static ArrayList < FCBlockAPI > BLOCKS = new ArrayList < FCBlockAPI > ();
  public static ArrayList < FCItemAPI > ITEMS = new ArrayList < FCItemAPI > ();

  //https://github.com/Trikzon/Snow-Variants/blob/1.13.2/src/main/java/trikzon/snowvariants/init/ModBlocks.java

  public static void registerBlock(FCBlockAPI block) {
    if (!GameRegistries.BlockKeyExistsInRegistry(block.getFCRegistryName())) {

      if (block instanceof VanillaBlock) {
    	  VanillaRegistries.registerBlock((VanillaBlock)block);
      } else { //When Dataified Blocks come out we need to make a similar trap
        UniversalRegistryGettersAndSetters.registerBlock(block);
        BLOCKS.add(block);
        GlobalRegistries.BLOCKS.add(block);
      }

    } else {
      System.out.println("The following block already exists in the Registry." + block.getFCRegistryName() );
    }

  }

  
  
  public static void registerItem(FCItemAPI item) {

	    if (!GameRegistries.ItemKeyExistsInRegistry(item.getFCRegistryName())) {

	        if (item instanceof VanillaItem) {
	        	VanillaRegistries.registerItem((VanillaItem)item);
            }else if (item instanceof DMRItem) //When other datafied come out I need to do for those to 
	        {
	        	DatafiedObjectRegistration.registerDMRItem((DMRItem)item);
	        }	        
	        else { //When Dataified Blocks come out we need to make a similar trap
	          UniversalRegistryGettersAndSetters.registerItem(item);
	          ITEMS.add(item);
	          GlobalRegistries.ITEMS.add(item);
	        }

	      } else {
	        System.out.println("The following item already exists in the Registry." + item.getFCRegistryName());
	      }
	  	  
  }

}