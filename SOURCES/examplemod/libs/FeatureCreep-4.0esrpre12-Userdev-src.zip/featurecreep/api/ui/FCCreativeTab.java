package featurecreep.api.ui;

import featurecreep.api.items.FCItem;
import featurecreep.api.ui.tabs.UnifiedItemGroupGetter;


public class FCCreativeTab implements UnifiedItemGroupGetter{

	public String id;	

	public FCCreativeTab(int index, String id, FCItem item)
	{

		
	}
	public FCCreativeTab()
	{

	}
	
	

	
	
	
	
}
