package featurecreep.api.blocks;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.jboss.dmr.ModelNode;

import featurecreep.api.blocknitem.BlockOrItem;

public interface FCBlockAPI extends BlockOrItem{

		  boolean getSingleSided(); //This is for convenience and also could possibly fix the single sided block issue

	  FCBlockAPI isSingleSided(boolean answer);
	  
	  public void setDownTextureName(String name);
	  public void setEastTextureName(String name);
	  public void setNorthTextureName(String name);
	  public void setParticleTextureName(String name);
	  public void setSouthTextureName(String name);
	  public void setUpTextureName(String name);
	  public void setWestTextureName(String name);

	  public String getDownTextureName();
	  public String getEastTextureName();
	  public String getNorthTextureName();
	  public String getParticleTextureName();
	  public String getSouthTextureName();
	  public String getUpTextureName();
	  public String getWestTextureName();
	  
	  default void registerModels() {
		
	  }
	
	
	
	
//		public default Block get()	{	} Internal API
	
	
}
