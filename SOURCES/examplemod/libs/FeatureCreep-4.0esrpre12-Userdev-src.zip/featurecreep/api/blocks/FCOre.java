package featurecreep.api.blocks;

import featurecreep.api.blocks.drop.BlockDropArrayObject;
import featurecreep.api.blocks.materials.UnifiedBlockMaterial;
import featurecreep.api.ui.FCCreativeTab;
import featurecreep.api.ui.tabs.UnifiedItemGroupGetter;

public class FCOre implements FCBlockAPI {

  	public featurecreep.api.blocknitem.BlocknItemFieldHolder holder = new featurecreep.api.blocknitem.BlocknItemFieldHolder();
	@Override public featurecreep.api.blocknitem.BlocknItemFieldHolder holder() {	return holder;	}
  
  
  public FCCreativeTab default_tab;
  public boolean single_sided = false;
  public BlockDropArrayObject[] drop_arrays;
  public Object resource;
          String topname;
	  String bottomname;
	  String leftname;
	  String rightname;
	  String frontname;
	  String backname;
	  
  public FCOre(int id, String modid, String name, UnifiedItemGroupGetter group, UnifiedBlockMaterial material, int strength, BlockDropArrayObject[] drops, Object ore_material) {
    
   setModId(modid);
	setUnlocName(name);
	setNumberID(id);
	setDefaultCreativeTab((FCCreativeTab)group); //This does not work but this is the userdev so does not need to be run so is ok
	registerModels();
    drop_arrays = drops;
resource = ore_material;
  }




 

  private void getDrops() {

  }
  
  
  
  @Override
  public boolean getSingleSided() {
    // TODO Auto-generated method stub
    return single_sided;
  }

  @Override
  public void setDownTextureName(String name) {
    // TODO Auto-generated method stub
    bottomname = name;
  }

  @Override
  public void setEastTextureName(String name) {
    // TODO Auto-generated method stub
    rightname = name;
  }

  @Override
  public void setNorthTextureName(String name) {
    // TODO Auto-generated method stub
    frontname = name;

  }

  @Override
  public void setParticleTextureName(String name) {
    // TODO Auto-generated method stub
    topname = name;
  }

  @Override
  public void setSouthTextureName(String name) {
    // TODO Auto-generated method stub
    backname = name;
  }

  @Override
  public void setUpTextureName(String name) {
    // TODO Auto-generated method stub
    topname = name;
  }

  @Override
  public void setWestTextureName(String name) {
    // TODO Auto-generated method stub
    leftname = name;
  }

  @Override
  public String getDownTextureName() {
    // TODO Auto-generated method stub
    return bottomname;
  }

  @Override
  public String getEastTextureName() {
    // TODO Auto-generated method stub
    return rightname;
  }

  @Override
  public String getNorthTextureName() {
    // TODO Auto-generated method stub
    return frontname;
  }

  @Override
  public String getParticleTextureName() {
    // TODO Auto-generated method stub
    return topname;
  }

  @Override
  public String getSouthTextureName() {
    // TODO Auto-generated method stub
    return backname;
  }

  @Override
  public String getUpTextureName() {
    // TODO Auto-generated method stub
    return topname;
  }

  @Override
  public String getWestTextureName() {
    // TODO Auto-generated method stub
    return leftname;
  }

  @Override
  public FCOre isSingleSided(boolean answer) {
	    single_sided = answer;
	return this;  
  }

}
