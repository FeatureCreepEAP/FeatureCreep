package featurecreep.api.blocks.vanilla;

import featurecreep.api.blocks.FCBlockAPI;

/**
TRY TO AVOID THIS CLASS, USE IN THE WRONG CIRCUMSTANCES CAN LEAD TO CRASH/MOD NOT LOADING. STAY WITHIN DOCUMENTATION UNLESS YOU REALLY KNOW WHAT YOU ARE DOING
**/
public class VanillaBlock implements FCBlockAPI{

		public featurecreep.api.blocknitem.BlocknItemFieldHolder holder = new featurecreep.api.blocknitem.BlocknItemFieldHolder();
	@Override public featurecreep.api.blocknitem.BlocknItemFieldHolder holder() {	return holder;	}
	
	
	//public Block vanilla_block; //BE VERY CAREFUL
	//public BlockState state; //BE EVEN MORE CAREFUL WITH THIS, MC SPECIFC TO NEW VERSIONS
	

	
	public VanillaBlock(FCBlockAPI block, String registry_name) //As a backup or for ported items
	{
//		this (block.get(), block.get().getDefaultState(),  registry_name);
	}
	
/*	Use Reflection or Mirror for these if you REALLY know what you are doing
	@Override
	public Block get()
	{
return 	vanilla_block; //BE VERY CAREFUL
	}

	public BlockState getFCBlockState() //BE EVEN MORE CAREFUL WITH THIS, MC SPECIFC TO NEW VERSIONS
	{
		return state;
	}
	
	*/
	
//We'ss do all these later, they dont really matter for this right now

	@Override
	public boolean getSingleSided() {
		// TODO Auto-generated method stub
		return false;
	}



	@Override
	public FCBlockAPI isSingleSided(boolean answer) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public void setDownTextureName(String name) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void setEastTextureName(String name) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void setNorthTextureName(String name) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void setParticleTextureName(String name) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void setSouthTextureName(String name) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void setUpTextureName(String name) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void setWestTextureName(String name) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public String getDownTextureName() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public String getEastTextureName() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public String getNorthTextureName() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public String getParticleTextureName() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public String getSouthTextureName() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public String getUpTextureName() {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public String getWestTextureName() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
