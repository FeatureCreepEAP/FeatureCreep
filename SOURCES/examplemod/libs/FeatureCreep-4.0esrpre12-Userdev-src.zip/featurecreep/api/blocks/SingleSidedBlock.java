package featurecreep.api.blocks;

import featurecreep.api.blocks.drop.BlockDropArrayObject;
import featurecreep.api.blocks.materials.UnifiedBlockMaterial;
import featurecreep.api.ui.tabs.UnifiedItemGroupGetter;

public class SingleSidedBlock extends FCBlock {

  public SingleSidedBlock(int id, String modid, String name, UnifiedItemGroupGetter group, UnifiedBlockMaterial material, int strength, BlockDropArrayObject[] drops) {
    super(id, modid, name, group, material, strength, drops);
   this.single_sided = true;
  }


}
