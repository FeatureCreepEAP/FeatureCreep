package featurecreep.api.blocks;

import featurecreep.api.blocks.drop.BlockDropArrayObject;
import featurecreep.api.blocks.materials.UnifiedBlockMaterial;
import featurecreep.api.ui.tabs.UnifiedItemGroupGetter;

public class FCSingleSidedOre extends FCOre {

	  public FCSingleSidedOre(int id, String modid, String name, UnifiedItemGroupGetter group, UnifiedBlockMaterial material, int strength, BlockDropArrayObject[] drops, Object ore_material) {
		    super(id, modid, name, group, material, strength, drops, ore_material);
		 this.single_sided = true;
		  }


}

