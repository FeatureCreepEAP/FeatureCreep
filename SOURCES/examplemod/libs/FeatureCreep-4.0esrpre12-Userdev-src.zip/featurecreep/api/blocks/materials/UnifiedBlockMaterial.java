package featurecreep.api.blocks.materials;

public interface UnifiedBlockMaterial {

	
//	public Object get(); //Does not do anything in DZ Do not use, internal API
	
	
}
