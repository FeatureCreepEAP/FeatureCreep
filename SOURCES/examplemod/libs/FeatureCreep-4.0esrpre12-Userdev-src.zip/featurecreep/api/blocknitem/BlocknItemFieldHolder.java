package featurecreep.api.blocknitem;

import featurecreep.api.ui.FCCreativeTab;

public class BlocknItemFieldHolder {

	public String public_modid;
	public String public_name;
	public int number_id;
	public FCCreativeTab default_tab;	
	
}