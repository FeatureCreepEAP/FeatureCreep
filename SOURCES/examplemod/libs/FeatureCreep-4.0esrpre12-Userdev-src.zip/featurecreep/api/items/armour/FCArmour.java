package featurecreep.api.items.armour;

import featurecreep.api.items.FCItemAPI;
import featurecreep.api.ui.FCCreativeTab;
import featurecreep.api.ui.tabs.UnifiedItemGroupGetter;

public class FCArmour implements FCItemAPI{

	
	
		public featurecreep.api.blocknitem.BlocknItemFieldHolder holder = new featurecreep.api.blocknitem.BlocknItemFieldHolder();
	@Override public featurecreep.api.blocknitem.BlocknItemFieldHolder holder() {	return holder;	}

	
	public FCArmour(int id, String modid, String name, UnifiedItemGroupGetter group, FCArmourMaterial material, FCArmourSlot slot) {
		// TODO Auto-generated constructor stub
		setModId(modid);
		setUnlocName(name);
		registerModels();
		setDefaultCreativeTab((FCCreativeTab)group); //This does not work but this is the userdev so does not need to be run so is ok
		setNumberID(id);
	
	}

}
