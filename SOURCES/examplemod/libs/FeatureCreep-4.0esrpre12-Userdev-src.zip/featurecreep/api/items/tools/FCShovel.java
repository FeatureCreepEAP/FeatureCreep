package featurecreep.api.items.tools;

import featurecreep.api.ui.FCCreativeTab;
import featurecreep.api.ui.tabs.UnifiedItemGroupGetter;

public class FCShovel implements ToolsAPI
{
		public featurecreep.api.blocknitem.BlocknItemFieldHolder holder = new featurecreep.api.blocknitem.BlocknItemFieldHolder();
	@Override public featurecreep.api.blocknitem.BlocknItemFieldHolder holder() {	return holder;	}
	
	public ToolFieldHolder tool_holder = new ToolFieldHolder();
	@Override	public ToolFieldHolder tool_holder() {	return tool_holder;	}

	
	public FCShovel(int id, String modid, String name, UnifiedItemGroupGetter group, FCToolMaterial material, int attackDamage, int attackSpeed)
	{
		setModId(modid);
		setUnlocName(name);
		setNumberID(id);
		setDefaultCreativeTab((FCCreativeTab)group); //This does not work but this is the userdev so does not need to be run so is ok
		registerModels();
		setFCToolMaterial(material);
		setToolAttackDamage(attackDamage);
		setAttackSpeed(attackSpeed);
		}

		
	
	
	
}
