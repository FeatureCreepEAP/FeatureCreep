package featurecreep.api.items.tools.datafied.dmr;

import org.jboss.dmr.ModelNode;

import featurecreep.api.items.datafied.dmr.FCItemAsDMR;
import featurecreep.api.items.tools.FCPickaxe;
import featurecreep.api.items.tools.FCToolMaterial;
import featurecreep.api.items.tools.ToolsAPI;
import featurecreep.api.parsers.ParseDMRItem;
import featurecreep.api.registries.UniversalRegistryGettersAndSetters;
import featurecreep.api.ui.tabs.UnifiedItemGroupGetter;
import featurecreep.content.FCItems;

public class FCPickaxeAsDMR extends FCItemAsDMR implements ToolsAPI 
{
	
	public featurecreep.api.items.tools.ToolFieldHolder tool_holder = new featurecreep.api.items.tools.ToolFieldHolder();
@Override	public featurecreep.api.items.tools.ToolFieldHolder tool_holder() {	return tool_holder;	}


	
	
	public FCPickaxeAsDMR(int id, String modid, String name, UnifiedItemGroupGetter group, FCToolMaterial material, int attackDamage, int attackSpeed)
	{
super (id, modid,name, group);
setFCToolMaterial(material);
setToolAttackDamage(attackDamage);
setAttackSpeed(attackSpeed);		
	}


	@Override
	public ModelNode toModelNode()
	{
		ModelNode node = super.toModelNode();
	    node.get("attack_damage").set(getToolAttackDamage());
	    node.get("attack_speed").set(getAttackSpeed());
	    node.get("material").get("max_uses").set(getFCToolMaterial().getToolMaxUses());
	    node.get("material").get("efficiency").set(getFCToolMaterial().getToolEfficiency());
	    node.get("material").get("attack_damage").set(getFCToolMaterial().getToolAttackDamage());
	    node.get("material").get("harvest_level").set(getFCToolMaterial().getToolHarvestLevel());
	    node.get("material").get("enchantability").set(getFCToolMaterial().getToolEnchantability());	
	    return node;
	}
	
	

//Do not use
public Object get()
{
ModelNode node = ParseDMRItem.getModelNodeFromDMRItem(this);
return new FCPickaxe(node.get("id").asInt(), node.get("modid").asString(), node.get("item_name").asString(), UniversalRegistryGettersAndSetters.getFCItemGroupbyName(node.get("group").asString()), new FCToolMaterial(node.get("material").get("harvest_level").asInt(), node.get("material").get("max_uses").asInt(), node.get("material").get("efficiency").asInt(), node.get("material").get("attack_damage").asInt(), node.get("material").get("enchantability").asInt(), FCItems.AMETHYST), node.get("attack_damage").asInt(), node.get("attack_speed").asInt());	
}
	
	
}
