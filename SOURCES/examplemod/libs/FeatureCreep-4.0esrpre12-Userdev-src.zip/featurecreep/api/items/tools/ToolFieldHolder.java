package featurecreep.api.items.tools;

public class ToolFieldHolder{

	public FCToolMaterial mat;
	public int damage;
	public int attackspeed;
	
}
