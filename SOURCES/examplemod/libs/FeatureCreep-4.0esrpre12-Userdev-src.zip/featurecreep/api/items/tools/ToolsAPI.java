package featurecreep.api.items.tools;

import featurecreep.api.items.FCItemAPI;

public interface ToolsAPI extends FCItemAPI{

	
	public ToolFieldHolder tool_holder();

	
	public default void setFCToolMaterial(FCToolMaterial mat)	{tool_holder().mat = mat;}
	public default void setToolAttackDamage(int damage) {tool_holder().damage = damage;}
	public default void setAttackSpeed(int attackspeed) {tool_holder().attackspeed = attackspeed;}
	
	public default FCToolMaterial getFCToolMaterial()	{return tool_holder().mat;}
	public default int getToolAttackDamage() {return tool_holder().damage;}
	public default int getAttackSpeed() {return tool_holder().attackspeed;}
	
}

