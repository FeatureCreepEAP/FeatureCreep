package featurecreep.api.items.datafied.dmr;

import org.jboss.dmr.ModelNode;

import featurecreep.api.items.FCItem;
import featurecreep.api.parsers.ParseDMRItem;
import featurecreep.api.registries.UniversalRegistryGettersAndSetters;
import featurecreep.api.ui.FCCreativeTab;
import featurecreep.api.ui.tabs.UnifiedItemGroupGetter;
import featurecreep.api.ui.tabs.vanilla.VanillaCreativeTab;

public class FCItemAsDMR implements DMRItem
{

	public featurecreep.api.blocknitem.BlocknItemFieldHolder holder = new featurecreep.api.blocknitem.BlocknItemFieldHolder();
	@Override public featurecreep.api.blocknitem.BlocknItemFieldHolder holder() {	return holder;	}
	
	UnifiedItemGroupGetter gettab;// Gotta add this to BlockOrItemAPI Holder
	
	public FCItemAsDMR(int id, String modid, String name, UnifiedItemGroupGetter group)
	{
		setModId(modid);
		setUnlocName(name);
		registerModels();
		setDefaultCreativeTab((FCCreativeTab)group); //This does not work but this is the userdev so does not need to be run so is ok
		setNumberID(id);
	gettab = group;
	}

	@Override
	public ModelNode toModelNode() {
		// TODO Auto-generated method stub
		ModelNode node = new ModelNode();
		node.get("type").set("generic_item");
		node.get("modid").set(getModId());
		node.get("item_name").set(getUnlocName());
		node.get("id").set(getNumberID());
        if(gettab instanceof VanillaCreativeTab) {
        	VanillaCreativeTab van = (VanillaCreativeTab)gettab;
        node.get("group").set(van.tabname);
        }else {
        	node.get("group").set(gettab.getTabName());	
        }
        
        return node;
        
	}

	
	//Do not use
	public Object get()
	{
ModelNode node = ParseDMRItem.getModelNodeFromDMRItem(this);
return new FCItem(node.get("id").asInt(), node.get("modid").asString(), node.get("item_name").asString(), UniversalRegistryGettersAndSetters.getFCItemGroupbyName(node.get("group").asString()));	
	}
	
	
	
	
}
