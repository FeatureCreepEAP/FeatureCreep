package featurecreep.api.items.datafied;

import featurecreep.api.items.FCItemAPI;

public interface DatafiedItem extends FCItemAPI{

	
	
}
