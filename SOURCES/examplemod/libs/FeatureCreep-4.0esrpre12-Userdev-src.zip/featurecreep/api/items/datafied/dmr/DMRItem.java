/**
 * 
 */
package featurecreep.api.items.datafied.dmr;

import org.jboss.dmr.ModelNode;

import featurecreep.api.items.datafied.DatafiedItem;

/**
 * @author rhel
 *
 */
public interface DMRItem extends DatafiedItem {

	public ModelNode toModelNode();
		
}

