package featurecreep.api.items;

import featurecreep.api.ui.FCCreativeTab;
import featurecreep.api.ui.tabs.UnifiedItemGroupGetter;

public class FCItem  implements FCItemAPI
{
	
	
		public featurecreep.api.blocknitem.BlocknItemFieldHolder holder = new featurecreep.api.blocknitem.BlocknItemFieldHolder();
	@Override public featurecreep.api.blocknitem.BlocknItemFieldHolder holder() {	return holder;	}
	
	public FCItem(int id, String modid, String name, UnifiedItemGroupGetter group)
	{
setModId(modid);
	setUnlocName(name);
	registerModels();
	setDefaultCreativeTab((FCCreativeTab)group); //This does not work but this is the userdev so does not need to be run so is ok
	setNumberID(id);
	}

	

}
