package featurecreep.api.items;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.jboss.dmr.ModelNode;

import featurecreep.api.blocknitem.BlockOrItem;

public interface FCItemAPI extends BlockOrItem {

  default void registerModels() {

  }


	//public default Item get()	{	} internal API


}
